#!/usr/bin/env python

from lib.base_action import BaseAction

class ValidatePortDetails(BaseAction):
    def __init__(self, config):
        """Creates a new Action given a StackStorm config object (kwargs works too)
        :param config: StackStorm configuration object for the pack
        :returns: a new Action
        """
        super(ValidatePortDetails, self).__init__(config)

    def format_output(self, port_output):
        ports = []
        list_data = port_output.split(',')[0].strip().split()
        no_of_ports = int(port_output.split(',')[1].strip())
        mstsc_status = port_output.split(',')[2].strip()
        list_index_value = int(len(list_data)/no_of_ports)
        cnt = list_index_value
        for item in range(0, no_of_ports):
            ports.append(list_data[cnt - 1])
            cnt += list_index_value
        ports_data = list(set(ports))
        print("Ports are: {}".format(ports_data))
        if len(ports_data) == 1 and ports_data[0] == '1020' and mstsc_status == 'True':
            port_status = (True, 'RDP_PORT_UP_MSTSC_CONNECTED')
        elif mstsc_status == 'True' and ports_data[0] != '1020':
            port_status = (True, 'MSTSC_CONNECTED_BUT_ON_DIFFERENT_PORTS')
        else:
            port_status = (False, 'RDP_PORT_DOWN_OR_ASSIGNED_TO_OTHER_PROCESSES_MSTSC_NOT_CONNECTED')
        return port_status

    def check_uptime_data(self, port_output, uptime_validate, uptime_threshold):
        uptime_hrs = float("{:.2f}".format(float(port_output) / 60))
        if uptime_hrs <= float(uptime_threshold):
            print("Automation detected that uptime was {} hours, threshold is set to {} hours. It appears the server was rebooted during the change window.".format(uptime_hrs, uptime_threshold))
            uptime_data = (True, "SERVER_REBOOTED")
        else:
            print("Automation detected that uptime was {} hours, threshold is set to {} hours. It appears the server was not rebooted during the change window.".format(uptime_hrs, uptime_threshold))
            uptime_data = (False, "SERVER_NOT_REBOOTED")
        return uptime_data

    def run(self, port_output, uptime_validate, uptime_threshold):
        if uptime_validate == "True":
            result = self.check_uptime_data(port_output, uptime_validate, uptime_threshold)
        elif uptime_validate == "False":
            result = self.format_output(port_output)
        return result