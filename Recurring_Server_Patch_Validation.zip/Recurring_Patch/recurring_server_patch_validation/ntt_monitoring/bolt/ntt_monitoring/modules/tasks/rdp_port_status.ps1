Param([String]$ci_address)

function check_rdp_port_status($ci_address)
{
    $port_status = (cmd /c 'netstat -ano | find ":3389" | find "LISTENING"')
    $line_cnt = ($port_status |  Measure-object -line).Lines
    $mstsc_status = (New-Object System.Net.Sockets.TCPClient -ArgumentList $ci_address, 3389).Connected
    write-output "$port_status, $line_cnt, $mstsc_status"
}

check_rdp_port_status $ci_address
