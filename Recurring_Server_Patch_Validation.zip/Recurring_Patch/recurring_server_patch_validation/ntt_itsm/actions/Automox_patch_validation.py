#!/usr/bin/env python

from lib.base_action import BaseAction
import requests

class Automoxpatchvalidation(BaseAction):
    def __init__(self, config):
        """Creates a new Action given a StackStorm config object (kwargs works too)
        :param config: StackStorm configuration object for the pack
        :returns: a new Action
        """
        super(Automoxpatchvalidation, self).__init__(config)

    def run(self, server):
         apikey = "4cccdd61-b639-472e-acb2-bfa72b76a818"
         orgid = "6777"
         #server = "WAWTCPSQL04N01"  #Will be dynamic and need to be passed as parameter to the action
         #automoxapi = "https://console.automox.com/api/orgs?api_key=" + apikey
         automoxapi = "https://console.automox.com/api/events?o=" + orgid + "&api_key=" + apikey
         user = "unix.automation.mailbox@nttdata.com"
         pass1 = "Os7tAR1r5zB7pLLrsEP5"

         r = requests.get(automoxapi, auth=('user', 'pass1'))
         #x = r.text
         xjson = r.json()
         serverflag = 0
         patch_flag = "failed"
         #print(x[0:100])
         #print(xjson)
         for data in xjson:
            #print(data["server_name"])
            if data:
                 if data["server_name"] == server:
                      serverflag = 1
                      try:
                           statuscode = data["data"]["status"]
                           print(statuscode)
                           if int(statuscode) == 0:
                                print(data["data"]["text"])
                                patches = data["data"]["text"]
                                patch_flag = "success"
                           else:
                                print("Status Code is not 0 and it is: {}".format(statuscode))
                                print(data["data"]["text"])
                                patches = data["data"]["text"]
                                patch_flag = "failed"
                      except KeyError:
                           continue
                           #print("Key not found")
                      #print(data)
         #   else:
         #        print("The server WAWTCPSQL04N01 we are looking for in not found in the output from Automox")
         #print(data)
         if serverflag == 0:
              print("server not found")
              server_found = "False"
              result = {"API_status_code":r.status_code, "Server_found":server_found, "patch_flag":patch_flag}
         else:
              server_found = "True"
              result = {"API_status_code":r.status_code, "Server_found":server_found, "Patch_status_code":statuscode, "Installed_patches": patches, "patch_flag":patch_flag}
         #return r.status_code
         return result