from lib.base_action import BaseAction

class StorageHcSomCreate(BaseAction):

    def __init__(self, config):
        """Creates a new Action given a StackStorm config object (kwargs works too)
        :param config: StackStorm configuration object for the pack
        :returns: a new Action
        """
        super(StorageHcSomCreate, self).__init__(config)


    def run(self,host_names_inc,company,requested_by,short_description,category,subcategory,assignment_group,impact,description):
        
        # REST API URL
        # endpoint = '/api/now/table/incident?sysparm_fields=number'
        # scripted/Customized API for NTT Data
        
        endpoint = '/api/ntt11/incident_automation_stackstorm/CreateIncident'
        
        # the below input fields only for Rest API
        incident=[]
        for item in host_names_inc:
            host=item.split(':',2)[0]
            ip_address=item.split(':',2)[1]
            worknotes=item.split(':',2)[2]            
            payload = {
                    'company': company,
                    'requested_by': requested_by,
                    'short_description': short_description,
                    'description': description + ip_address +'\n'+worknotes,
                    'cmdb_ci': host,
                    'category' : category,
                    'subcategory' : subcategory,
                    'assignment_group': assignment_group,
                    'impact': impact
                }
            print(payload)
            inc = self.sn_api_call('POST', endpoint, payload=payload)
            incident.append(inc)
            
        return incident

