#!/usr/bin/env python

from lib.base_action import BaseAction
from os.path import basename
import smtplib
import email.utils
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.application import MIMEApplication


class StorageHealthcheckSendEmailNotificationsWithAttachment(BaseAction):
    def __init__(self, config):
        """Creates a new Action given a StackStorm config object (kwargs works too)
        :param config: StackStorm configuration object for the pack
        :returns: a new Action
        """
        super(StorageHealthcheckSendEmailNotificationsWithAttachment, self).__init__(config)

    def send_email(self, port, smtp_server, msg_subject, msg_from, msg_to, msg_body, file_name, failed_connection_ip, company):
        send_mail_sts = (False, 'NONE')
        msg_body_data = "HealthCheck Report"
        message = MIMEMultipart(msg_body_data)
        msg_to = msg_to.split(';')
        message['To'] = email.utils.formataddr(('Recipient',';'.join(msg_to)))
        message['From'] = email.utils.formataddr(('Stackstorm Report', msg_from))
        message['Subject'] ='Account : '+ company + ' - '+ msg_subject
        if(len(failed_connection_ip)>0):
            msg_body = msg_body + " Note: Connection to Servers "+ ', '.join(failed_connection_ip) +" failed"
        part2 = MIMEText(msg_body, "plain")
        message.attach(part2)
        
        with open(file_name, "rb") as fil:
            part = MIMEApplication(
                fil.read(),
                Name=basename(file_name)
            )
            
        part['Content-Disposition'] = 'attachment; filename="%s"' % basename(file_name)
        message.attach(part)

        server = smtplib.SMTP(smtp_server, port)
        server.set_debuglevel(False)
        try:
            server.sendmail(msg_from, msg_to, message.as_string())
            send_mail_sts = (True, 'MAIL_SENT_SUCCESSFULLY')
        except Exception as e:
            send_mail_sts = (False, ('ERROR_SENDING_MAIL', e))
        finally:
            server.quit()
        return send_mail_sts

    def run(self, port, smtp_server, msg_subject, msg_from, msg_to, msg_body, file_name, failed_connection_ip, company):
        mail_data = self.send_email(port, smtp_server, msg_subject, msg_from, msg_to, msg_body, file_name, failed_connection_ip, company)
        return mail_data

