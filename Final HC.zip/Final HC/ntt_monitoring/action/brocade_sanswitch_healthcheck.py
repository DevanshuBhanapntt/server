#!/usr/bin/env python
# Copyright 2019 NTT Technologies
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
from st2common.runners.base_action import Action
import json
import subprocess
import paramiko
import os
import re

class BrocadeSanswitchHealthcheck(Action):
    def __init__(self, config):
        """Creates a new Action given a StackStorm config object (kwargs works too)
        :param config: StackStorm configuration object for the pack
        :returns: a new Action
        """
        super(BrocadeSanswitchHealthcheck, self).__init__(config)

    def run(self, company, server_details):
        commands=['psshow','fanshow','tempshow','sensorshow','switchshow','mapsdb --show','sfpshow -health']
        cmd_val=['Power Supply','Fan Show','Temp Show','Sensor Show','Switch Show','Mapsdb Show','SFP Show']
        text = '''<html><body>
<table width="100%">
<tbody><tr bgcolor="#66b5ff">
<td colspan="7" height="25" align="center">
<strong>
<font color="#003399" size="4" face="tahoma">Brocade Switch HealthCheck Report</font>
</strong></td>
</tr>
</tbody></table>'''
        inc_flag=0
        failed_connection_ip=[]
        table_text=''
        failed_CI_names=[]
        db_list={}
        db_status='P'
        company_name=company
        for i in server_details:
            host=server_details[i]["CI_Name"]
            ip_address=server_details[i]["ip_address"]
            uname=server_details[i]["uname"]
            password=server_details[i]["password"]
            inc_notes=''
            server_connection, ip_address= self.check_connectivity_status(host,ip_address)
            if server_connection == False:
               failed_connection_ip.append(ip_address)
               db_status='F'
               db_list[host]=[ip_address,db_status,'Connection Error']
            else:
               try:
                   print("establishing ssh connection.....")
                   ssh = paramiko.SSHClient()
                   ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
                   ssh.connect(hostname=ip_address,username=uname,password=password)
                   print("SSH Connection established.....")
                   tablet='''<table><tbody><tr bgcolor="#66b5ff"><td><b>Brocade Switch IP</b></td> <td><b>'''+ ip_address+'''</b></td></tr>'''
                   cmd_text=''
                   for cmd in range(len(commands)):
                       ssh_stdin, ssh_stdoutput, ssh_stderr = ssh.exec_command(commands[cmd])
                       stdout=ssh_stdoutput.read().decode('utf-8')
                       stderr=ssh_stderr.read().decode('utf-8')
                       if stdout == "" and stderr!= '':
                           cmd_text=cmd_text+'''<tr bgcolor="#cce6ff"> <td width="8%"><table><tbody><tr><td width="5%" align="center" bgcolor="#cce6ff" <="" td=""></td><td width="8%" align="center" bgcolor="#cce6ff" face="tahoma">'''+commands[cmd]+'''</td></tr></tbody></table></td><td width="10%" align="left" face="tahoma"><br>Unable to execute the command</td></tr>'''
                       else:
                           if stdout!= '':
                               stdoutput = stdout.split('\n')
                               if (commands[cmd]=='psshow'):
                                   colour='green'
                                   for line in stdoutput:
                                       if ('is Faulty' in line):
                                           colour='red'
                                   if (colour=="red"):
                                        cmd_text=cmd_text+'''<tr bgcolor="#cce6ff"> <td width="8%"><table><tbody><tr><td width="5%" align="center" bgcolor="#ff3333" <="" td=""></td><td width="8%" align="center" bgcolor="#cce6ff" face="tahoma">'''+commands[cmd]+'''</td></tr></tbody></table></td><td width="10%" align="left" face="tahoma"><br>'''+'<br>'.join(stdoutput)+'''</td></tr>'''
                                        inc_flag=1
                                        #failed_CI_names.append(host)
                                        inc_notes=inc_notes+'\n'+stdout+'\n'

                                   else:
                                        cmd_text=cmd_text+'''<tr bgcolor="#cce6ff"> <td width="8%"><table><tbody><tr><td width="5%" align="center" bgcolor="#00b300" <="" td=""></td><td width="8%" align="center" bgcolor="#cce6ff" face="tahoma">'''+commands[cmd]+'''</td></tr></tbody></table></td><td width="10%" align="left" face="tahoma"><br>'''+'<br>'.join(stdoutput)+'''</td></tr>'''

                               elif (commands[cmd]=='fanshow'):
                                   colour='green'                               
                                   for line in stdoutput:
                                       if ('is Faulty' in line):
                                           colour='red'
                                   if (colour=="red"):
                                        cmd_text=cmd_text+'''<tr bgcolor="#cce6ff"> <td width="8%"><table><tbody><tr><td width="5%" align="center" bgcolor="#ff3333" <="" td=""></td><td width="8%" align="center" bgcolor="#cce6ff" face="tahoma">'''+commands[cmd]+'''</td></tr></tbody></table></td><td width="10%" align="left" face="tahoma"><br>'''+'<br>'.join(stdoutput)+'''</td></tr>'''
                                        inc_flag=1
                                        #failed_CI_names.append(host)
                                        inc_notes=inc_notes+'\n'+stdout+'\n'

                                   else:
                                        cmd_text=cmd_text+'''<tr bgcolor="#cce6ff"> <td width="8%"><table><tbody><tr><td width="5%" align="center" bgcolor="#00b300" <="" td=""></td><td width="8%" align="center" bgcolor="#cce6ff" face="tahoma">'''+commands[cmd]+'''</td></tr></tbody></table></td><td width="10%" align="left" face="tahoma"><br>'''+'<br>'.join(stdoutput)+'''</td></tr>'''

                               elif (commands[cmd]=='tempshow'):
                                    for line in stdoutput:
                                       if ('Ok' not in line):
                                           colour='red'
                                       else:
                                           colour='green'
                                           break
                                    if (colour=="red"):
                                        cmd_text=cmd_text+'''<tr bgcolor="#cce6ff"> <td width="8%"><table><tbody><tr><td width="5%" align="center" bgcolor="#ff3333" <="" td=""></td><td width="8%" align="center" bgcolor="#cce6ff" face="tahoma">'''+commands[cmd]+'''</td></tr></tbody></table></td><td width="10%" align="left" face="tahoma"><br>'''+'<br>'.join(stdoutput)+'''</td></tr>'''
                                        inc_flag=1
                                        #failed_CI_names.append(host)
                                        inc_notes=inc_notes+'\n'+stdout+'\n'
                                    else:
                                        cmd_text=cmd_text+'''<tr bgcolor="#cce6ff"> <td width="8%"><table><tbody><tr><td width="5%" align="center" bgcolor="#00b300" <="" td=""></td><td width="8%" align="center" bgcolor="#cce6ff" face="tahoma">'''+commands[cmd]+'''</td></tr></tbody></table></td><td width="10%" align="left" face="tahoma"><br>'''+'<br>'.join(stdoutput)+'''</td></tr>'''

                               elif (commands[cmd]=='sensorshow'):
                                    colour='green'
                                    for line in stdoutput:
                                       if ('is Faulty' in line):
                                           colour='red'
                                    if (colour=="red"):
                                        cmd_text=cmd_text+'''<tr bgcolor="#cce6ff"> <td width="8%"><table><tbody><tr><td width="5%" align="center" bgcolor="#ff3333" <="" td=""></td><td width="8%" align="center" bgcolor="#cce6ff" face="tahoma">'''+commands[cmd]+'''</td></tr></tbody></table></td><td width="10%" align="left" face="tahoma"><br>'''+'<br>'.join(stdoutput)+'''</td></tr>'''
                                    else:
                                        cmd_text=cmd_text+'''<tr bgcolor="#cce6ff"> <td width="8%"><table><tbody><tr><td width="5%" align="center" bgcolor="#00b300" <="" td=""></td><td width="8%" align="center" bgcolor="#cce6ff" face="tahoma">'''+commands[cmd]+'''</td></tr></tbody></table></td><td width="10%" align="left" face="tahoma"><br>'''+'<br>'.join(stdoutput)+'''</td></tr>'''

                               elif (commands[cmd]=='switchshow'):
                                    output=''
                                    colour='green'
                                    for line in stdoutput:
                                        if ('switchState' in line):
                                            if ('Online' not in line):
                                                colour='red'
                                            else:
                                                output=output+line+'<br><br>'
                                                break

                                    for line in stdoutput:
                                        if ('Index' in line):
                                            stindex=stdoutput.index(line)
                                    output=output+'<br>'.join(stdoutput[stindex:])
                                    if (colour=="red"):
                                        cmd_text=cmd_text+'''<tr bgcolor="#cce6ff"> <td width="8%"><table><tbody><tr><td width="5%" align="center" bgcolor="#ff3333" <="" td=""></td><td width="8%" align="center" bgcolor="#cce6ff" face="tahoma">'''+commands[cmd]+'''</td></tr></tbody></table></td><td width="10%" align="left" face="tahoma"><br>'''+output+'''</td></tr>'''
                                    else:
                                        cmd_text=cmd_text+'''<tr bgcolor="#cce6ff"> <td width="8%"><table><tbody><tr><td width="5%" align="center" bgcolor="#00b300" <="" td=""></td><td width="8%" align="center" bgcolor="#cce6ff" face="tahoma">'''+commands[cmd]+'''</td></tr></tbody></table></td><td width="10%" align="left" face="tahoma"><br>'''+output+'''</td></tr>'''


                               elif (commands[cmd]=='mapsdb --show'):
                                    output=''
                                    colour='green'
                                    for line in stdoutput:
                                        if ('Current Switch Policy Status' in line):
                                            if ('HEALTHY' not in line):
                                                colour='red'
                                    if ('3.1 Summary Report:' in stdoutput):
                                        sindex=stdoutput.index('3.1 Summary Report:')+3
                                    if ('3.2 Rules Affecting Health:' in stdoutput):
                                        lindex=stdoutput.index('3.2 Rules Affecting Health:')
                                    index= slice(sindex, lindex)
                                    output=output+'<br>'.join(stdoutput[index])
                                    if (colour=="red"):
                                        cmd_text=cmd_text+'''<tr bgcolor="#cce6ff"> <td width="8%"><table><tbody><tr><td width="5%" align="center" bgcolor="#ff3333" <="" td=""></td><td width="8%" align="center" bgcolor="#cce6ff" face="tahoma">'''+commands[cmd]+'''</td></tr></tbody></table></td><td width="10%" align="left" face="tahoma"><br>'''+output+'''</td></tr>'''
                                    else:
                                        cmd_text=cmd_text+'''<tr bgcolor="#cce6ff"> <td width="8%"><table><tbody><tr><td width="5%" align="center" bgcolor="#00b300" <="" td=""></td><td width="8%" align="center" bgcolor="#cce6ff" face="tahoma">'''+commands[cmd]+'''</td></tr></tbody></table></td><td width="10%" align="left" face="tahoma"><br>'''+output+'''</td></tr>'''

                               elif (commands[cmd]=='sfpshow -health'):
                                    portids=[]
                                    port_output=''

                                    for line in stdoutput:
                                       if (('Green' in line) or ('No License' in line)):
                                           colour='green'
                                       else:
                                           if(line!='' and ('id' in line)):
                                               x = re.search('Port(.*)id', line)
                                               if x:
                                                   portids.append((x.group(1).split(':')[0]).strip())
                                                   colour='red'
                                    for pid in portids:
                                        poutput=''
                                        ssh_stdin, ssh_stdoutput, ssh_stderr = ssh.exec_command('sfpshow '+pid)
                                        port_cmd='sfpshow '+str(pid)+'<br>--------------------------<br>'
                                        port_cmd_out=ssh_stdoutput.read().decode('utf-8')
                                        for line in port_cmd_out.split('\n'):
                                            if (('Transceiver' in line) or ('Wavelength' in line) or  ('Current' in line) or ('Voltage' in line) or ('RX Power' in line) or ('TX Power' in line)):
                                                 poutput= poutput+line+'<br>'
                                        pcmd_output= port_cmd+ poutput +'<br>'
                                        port_output=port_output+pcmd_output

                                    if (colour=="red"):
                                        cmd_text=cmd_text+'''<tr bgcolor="#cce6ff"> <td width="8%"><table><tbody><tr><td width="5%" align="center" bgcolor="#ff3333" <="" td=""></td><td width="8%" align="center" bgcolor="#cce6ff" face="tahoma">'''+commands[cmd]+'''</td></tr></tbody></table></td><td width="10%" align="left" face="tahoma"><br>'''+port_output+'''</td></tr>'''
                                    else:
                                        output= "All Ports are Green"
                                        cmd_text=cmd_text+'''<tr bgcolor="#cce6ff"> <td width="8%"><table><tbody><tr><td width="5%" align="center" bgcolor="#00b300" <="" td=""></td><td width="8%" align="center" bgcolor="#cce6ff" face="tahoma">'''+commands[cmd]+'''</td></tr></tbody></table></td><td width="10%" align="left" face="tahoma"><br>'''+output+'''</td></tr>'''
                       cmd_text=cmd_text.replace(commands[cmd],cmd_val[cmd])
                       cmd_text=cmd_text.replace('\t','     ')
                   if(len(inc_notes)>0):
                       db_status='F'
                       failed_CI_names.append(host+':'+ip_address+":"+inc_notes)
                       db_list[host]=[ip_address,db_status,'Error in executed commands']
                   else:
                       db_status='P'
                       db_list[host]=[ip_address,db_status,'Commands executed successfully']
                   table_text=table_text+tablet+cmd_text+'''</tbody></table>'''
               except Exception as e:
                    print("An exception occurred: "+e)


        text=text+table_text+'''</body></html>'''
        if(company_name == 'Graphic Packaging'):
            file_path= '/opt/stackstorm/packs/ntt_monitoring/actions/'+'gpi_'+'brocade_switch_report.html'
        else:
            file_path= '/opt/stackstorm/packs/ntt_monitoring/actions/'+'brocade_switch_report.html'
        file = open(file_path,"w")
        file.write(text)
        file.close()

        return {'inc_flag': inc_flag,
                'failed_CI_names': failed_CI_names,
                'failed_connection_ip':failed_connection_ip,
                'file_path':file_path,
                'company_name':company_name,
                'db_list':db_list}



    def check_connectivity_status(self, host, ip_address):
        response = os.system("ping -c 1 " + ip_address)
        if response == 0:
          print("connection successful to the host "+host)
          return (True, ip_address )
        else:
          print("connection failed to the host "+host)
          return (False, ip_address)


