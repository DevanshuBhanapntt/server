#!/usr/bin/env python
# Copyright 2019 NTT Technologies
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
from st2common.runners.base_action import Action
import json
import subprocess
import paramiko
import os
import re
from datetime import date

class NetappHealthcheck(Action):
    def __init__(self, config):
        """Creates a new Action given a StackStorm config object (kwargs works too)
        :param config: StackStorm configuration object for the pack
        :returns: a new Action
        """
        super(NetappHealthcheck, self).__init__(config)

    def run(self, company, server_details):
        commands=['system health status show','system health subsystem show','system health config show','storage disk show -broken','storage shelf show -connectivity','storage port show','system fru-check show']
        cmd_val=['SystemHealth Show','SubSystem Health','SystemHealth Config Show','Disk Show','Shelf Show','Storage Port Show','fru_check Show']
        text = '''<html><body>
<table width="100%">
<tbody><tr bgcolor="#66b5ff">
<td colspan="7" height="25" align="center">
<strong>
<font color="#003399" size="4" face="tahoma">NetApp HealthCheck Report ('''+str(date.today())+''')</font>
</strong></td>
</tr>
</tbody></table>'''
        inc_flag=0
        failed_connection_ip=[]
        table_text=''
        failed_CI_names=[]
        db_list={}
        db_status='P'
        company_name=company
        for i in server_details:
            host=server_details[i]["CI_Name"]
            ip_address=server_details[i]["ip_address"]
            uname=server_details[i]["uname"]
            password=server_details[i]["password"]
            inc_notes=''
            server_connection, ip_address= self.check_connectivity_status(ip_address)
            if server_connection == False:
               failed_connection_ip.append(ip_address)
               db_status='F'
               db_list[host]=[ip_address,db_status,'Connection Error']
            else:
               try:
                   print("establishing ssh connection.....")
                   ssh = paramiko.SSHClient()
                   ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
                   ssh.connect(hostname=ip_address,username=uname,password=password)
                   print("SSH Connection established.....")
                   tablet='''<table><tbody><tr bgcolor="#66b5ff"><td><b>NetAPP IP</b></td> <td><b>'''+ ip_address+'''</b></td></tr>'''
                   cmd_text=''
                   for cmd in range(len(commands)):
                       ssh_stdin, ssh_stdoutput, ssh_stderr = ssh.exec_command(commands[cmd])
                       stdout=ssh_stdoutput.read().decode('utf-8')
                       stderr=ssh_stderr.read().decode('utf-8')
                       if stdout == "" and stderr!= '':
                           cmd_text=cmd_text+'''<tr bgcolor="#cce6ff"> <td width="8%"><table><tbody><tr><td width="5%" align="center" bgcolor="#cce6ff" <="" td=""></td><td width="8%" align="center" bgcolor="#cce6ff" face="tahoma">'''+commands[cmd]+'''</td></tr></tbody></table></td><td width="10%" align="left" face="tahoma"><br>Unable to execute the command</td></tr>'''
                       else:
                           if stdout!= '':
                               stdoutput = stdout.split('\n')
                               if (commands[cmd]=='system health status show'):
                                   if ('ok' in stdout):
                                       colour='green'
                                   else:
                                       colour='red'
                                   if (colour=="red"):
                                        cmd_text=cmd_text+'''<tr bgcolor="#cce6ff"> <td width="8%"><table><tbody><tr><td width="5%" align="center" bgcolor="#ff3333" <="" td=""></td><td width="8%" align="center" bgcolor="#cce6ff" face="tahoma">'''+commands[cmd]+'''</td></tr></tbody></table></td><td width="10%" align="left" face="tahoma"><br>'''+'<br>'.join(stdoutput)+'''</td></tr>'''
                                        inc_flag=1
                                        #failed_CI_names.append(host)
                                        inc_notes=inc_notes+'\n'+stdout+'\n'
                                        
                                   else:
                                        cmd_text=cmd_text+'''<tr bgcolor="#cce6ff"> <td width="8%"><table><tbody><tr><td width="5%" align="center" bgcolor="#00b300" <="" td=""></td><td width="8%" align="center" bgcolor="#cce6ff" face="tahoma">'''+commands[cmd]+'''</td></tr></tbody></table></td><td width="10%" align="left" face="tahoma"><br>'''+'<br>'.join(stdoutput)+'''</td></tr>'''

                               elif (commands[cmd]=='system health subsystem show'):                                   
                                   output=[ele for ele in stdoutput if ele.strip()][:-1]
                                   stdoutput=output[2:]
                                   colour='green'
                                   for line in stdoutput:
                                       if ('ok' not in line):
                                           colour='red'
                                   if (colour=="red"):
                                        cmd_text=cmd_text+'''<tr bgcolor="#cce6ff"> <td width="8%"><table><tbody><tr><td width="5%" align="center" bgcolor="#ff3333" <="" td=""></td><td width="8%" align="center" bgcolor="#cce6ff" face="tahoma">'''+commands[cmd]+'''</td></tr></tbody></table></td><td width="10%" align="left" face="tahoma"><br>'''+'<br>'.join(output)+'''</td></tr>'''
                                        inc_flag=1
                                        #failed_CI_names.append(host)
                                        inc_notes=inc_notes+'\n'+stdout+'\n'

                                   else:
                                        cmd_text=cmd_text+'''<tr bgcolor="#cce6ff"> <td width="8%"><table><tbody><tr><td width="5%" align="center" bgcolor="#00b300" <="" td=""></td><td width="8%" align="center" bgcolor="#cce6ff" face="tahoma">'''+commands[cmd]+'''</td></tr></tbody></table></td><td width="10%" align="left" face="tahoma"><br>'''+'<br>'.join(output)+'''</td></tr>'''

                               elif (commands[cmd]=='system health config show'):
                                    output=[ele for ele in stdoutput if ele.strip()][:-1]
                                    stdoutput=output[2:]
                                    colour='green'
                                    for line in stdoutput:
                                       if ('ok' not in line):
                                           colour='red'
                                    if (colour=="red"):
                                        cmd_text=cmd_text+'''<tr bgcolor="#cce6ff"> <td width="8%"><table><tbody><tr><td width="5%" align="center" bgcolor="#ff3333" <="" td=""></td><td width="8%" align="center" bgcolor="#cce6ff" face="tahoma">'''+commands[cmd]+'''</td></tr></tbody></table></td><td width="10%" align="left" face="tahoma"><br>'''+'<br>'.join(output)+'''</td></tr>'''
                                        inc_flag=1
                                        #failed_CI_names.append(host)
                                        inc_notes=inc_notes+'\n'+stdout+'\n'
                                    else:
                                        cmd_text=cmd_text+'''<tr bgcolor="#cce6ff"> <td width="8%"><table><tbody><tr><td width="5%" align="center" bgcolor="#00b300" <="" td=""></td><td width="8%" align="center" bgcolor="#cce6ff" face="tahoma">'''+commands[cmd]+'''</td></tr></tbody></table></td><td width="10%" align="left" face="tahoma"><br>'''+'<br>'.join(output)+'''</td></tr>'''

                               elif (commands[cmd]=='storage disk show -broken'):
                                    #for line in stdoutput:
                                    if (stdout and 'There are no entries matching your query.' in stdout):
                                        colour='green'
                                    else:
                                        colour='red'
                                    if (colour=="red"):
                                        cmd_text=cmd_text+'''<tr bgcolor="#cce6ff"> <td width="8%"><table><tbody><tr><td width="5%" align="center" bgcolor="#ff3333" <="" td=""></td><td width="8%" align="center" bgcolor="#cce6ff" face="tahoma">'''+commands[cmd]+'''</td></tr></tbody></table></td><td width="10%" align="left" face="tahoma"><br>'''+'<br>'.join(stdoutput)+'''</td></tr>'''
                                        inc_flag=1
                                        #failed_CI_names.append(host)
                                        inc_notes=inc_notes+'\n'+stdout+'\n'                                   
                                    else:
                                        cmd_text=cmd_text+'''<tr bgcolor="#cce6ff"> <td width="8%"><table><tbody><tr><td width="5%" align="center" bgcolor="#00b300" <="" td=""></td><td width="8%" align="center" bgcolor="#cce6ff" face="tahoma">'''+commands[cmd]+'''</td></tr></tbody></table></td><td width="10%" align="left" face="tahoma"><br>'''+'No Broken Disks'+'''</td></tr>'''

                               elif (commands[cmd]=='storage port show'):
                                    output=[ele for ele in stdoutput if ele.strip()][:-1]
                                    stdoutput=output[2:]
                                    colour='green'
                                    for line in stdoutput:
                                       if (line!='' and 'offline' in line):
                                           colour='red'
                                    if (colour=="red"):
                                        cmd_text=cmd_text+'''<tr bgcolor="#cce6ff"> <td width="8%"><table><tbody><tr><td width="5%" align="center" bgcolor="#ff3333" <="" td=""></td><td width="8%" align="center" bgcolor="#cce6ff" face="tahoma">'''+commands[cmd]+'''</td></tr></tbody></table></td><td width="10%" align="left" face="tahoma"><br>'''+'<br>'.join(output)+'''</td></tr>'''
                                        inc_flag=1
                                        #failed_CI_names.append(host)
                                        inc_notes=inc_notes+'\n'+stdout+'\n'                                   
                                    else:
                                        cmd_text=cmd_text+'''<tr bgcolor="#cce6ff"> <td width="8%"><table><tbody><tr><td width="5%" align="center" bgcolor="#00b300" <="" td=""></td><td width="8%" align="center" bgcolor="#cce6ff" face="tahoma">'''+commands[cmd]+'''</td></tr></tbody></table></td><td width="10%" align="left" face="tahoma"><br>'''+'<br>'.join(output)+'''</td></tr>'''


                               elif (commands[cmd]=='storage shelf show -connectivity'):
                                    output=[]
                                    colour='green'
                                    for line in stdoutput:
                                        if ( 'Shelf Name' in line or 'Stack ID' in line or 'Shelf UID' in line or 'Shelf ID' in line or 'Serial Number' in line or 'Module Type' in line or 'Model' in line or 'Shelf Vendor' in line or
                                             'Disk Count' in line or 'Connection Type' in line or 'Shelf State' in line or 'Status' in line):
                                            if('Shelf Name' in line):
                                                output.append('<br>'+line.strip()+'<br>')
                                            else:
                                                output.append(line.strip()+'<br>')
                                    for line in output:
                                        if (line!='' and 'Shelf State' in line):
                                            if('Online' not in line):
                                                colour='red'
                                        elif(line!='' and 'Status' in line):
                                            if('Normal' not in line):
                                                colour='red'
                                    if (colour=="red"):
                                        cmd_text=cmd_text+'''<tr bgcolor="#cce6ff"> <td width="8%"><table><tbody><tr><td width="5%" align="center" bgcolor="#ff3333" <="" td=""></td><td width="8%" align="center" bgcolor="#cce6ff" face="tahoma">'''+commands[cmd]+'''</td></tr></tbody></table></td><td width="10%" align="left" face="tahoma"><br>'''+''.join(output)+'''</td></tr>'''
                                        inc_flag=1
                                        #failed_CI_names.append(host)
                                        inc_notes=inc_notes+'\n'+stdout+'\n'                                    
                                    else:
                                        cmd_text=cmd_text+'''<tr bgcolor="#cce6ff"> <td width="8%"><table><tbody><tr><td width="5%" align="center" bgcolor="#00b300" <="" td=""></td><td width="8%" align="center" bgcolor="#cce6ff" face="tahoma">'''+commands[cmd]+'''</td></tr></tbody></table></td><td width="10%" align="left" face="tahoma"><br>'''+''.join(output)+'''</td></tr>'''

                               elif (commands[cmd]=='system fru-check show'):
                                    output=[ele for ele in stdoutput if ele.strip()][:-1]
                                    stdoutput=output[2:]
                                    colour='green'
                                    for line in stdoutput:
                                       if (line!='' and ('fail' in line or 'unknown' in line)):
                                           colour='red'
                                    if (colour=="red"):
                                        cmd_text=cmd_text+'''<tr bgcolor="#cce6ff"> <td width="8%"><table><tbody><tr><td width="5%" align="center" bgcolor="#ff3333" <="" td=""></td><td width="8%" align="center" bgcolor="#cce6ff" face="tahoma">'''+commands[cmd]+'''</td></tr></tbody></table></td><td width="10%" align="left" face="tahoma"><br>'''+'<br>'.join(output)+'''</td></tr>'''
                                        inc_flag=1
                                        #failed_CI_names.append(host)
                                        inc_notes=inc_notes+'\n'+stdout+'\n'                                    
                                    else:
                                        cmd_text=cmd_text+'''<tr bgcolor="#cce6ff"> <td width="8%"><table><tbody><tr><td width="5%" align="center" bgcolor="#00b300" <="" td=""></td><td width="8%" align="center" bgcolor="#cce6ff" face="tahoma">'''+commands[cmd]+'''</td></tr></tbody></table></td><td width="10%" align="left" face="tahoma"><br>'''+'<br>'.join(output)+'''</td></tr>'''
                       cmd_text=cmd_text.replace(commands[cmd],cmd_val[cmd])
                       cmd_text=cmd_text.replace('\t','     ')
                   if(len(inc_notes)>0):
                       db_status='F'
                       failed_CI_names.append(host+':'+ip_address+":"+inc_notes)
                       db_list[host]=[ip_address,db_status,'Error in executed commands']
                   else:
                       db_status='P'
                       db_list[host]=[ip_address,db_status,'Commands executed successfully']
                   table_text=table_text+tablet+cmd_text+'''</tbody></table>'''
               except Exception as e:
                    print("An exception occurred: "+str(e))


        text=text+table_text+'''</body></html>'''
        if(company_name == 'Graphic Packaging'):
            file_path= '/opt/stackstorm/packs/ntt_monitoring/actions/'+'gpi_'+'netapp_healthcheck_report.html'
        else:
            file_path= '/opt/stackstorm/packs/ntt_monitoring/actions/'+'netapp_healthcheck_report.html'
        file = open(file_path,"w")
        file.write(text)
        file.close()

        return {'inc_flag': inc_flag,
                'failed_CI_names': failed_CI_names,
                'failed_connection_ip':failed_connection_ip,
                'file_path':file_path,
                'company_name':company_name,
                'db_list':db_list}



    def check_connectivity_status(self, ip_address):
        response = os.system("ping -c 1 " + ip_address)
        if response == 0:
          print("connection successful to the host "+str(ip_address))
          return (True, ip_address )
        else:
          print("connection failed to the host "+str(ip_address))
          return (False, ip_address)


